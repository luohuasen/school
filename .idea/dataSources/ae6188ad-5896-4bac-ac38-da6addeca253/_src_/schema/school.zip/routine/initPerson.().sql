CREATE PROCEDURE `initPerson`()
  BEGIN
	DECLARE i INT DEFAULT 1;
	DECLARE sex VARCHAR(2);
	WHILE i < 91 DO
		IF i%2 = 0 
		THEN
			SET sex = "男";
		ELSE
			SET sex = "女";
		END IF;
		INSERT INTO person VALUES (10+i, "某某同学", sex, FLOOR(7 + RAND()*13)),
		 (111+i, "某某老师", sex, FLOOR(30 + RAND()*30));
		SET i = i + 1;
	END WHILE;
END