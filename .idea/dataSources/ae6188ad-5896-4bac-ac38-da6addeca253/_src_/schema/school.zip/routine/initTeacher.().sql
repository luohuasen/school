CREATE PROCEDURE `initTeacher`()
  BEGIN
	DECLARE subjectid INT;
  DECLARE pid INT DEFAULT 101;

	DECLARE flag INT;
	DECLARE cur CURSOR for SELECT id FROM subject s WHERE s.id > 300000;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag=1; 
	SET flag = 0;  
	open cur;  
		REPEAT 
			fetch cur into subjectid;
			INSERT INTO teacher VALUE ((1416000+pid),pid,subjectid);
			SET pid = pid +1;
			UNTIL flag
		END REPEAT;  
	close cur;  
END